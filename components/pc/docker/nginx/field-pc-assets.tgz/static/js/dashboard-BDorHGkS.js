import{j as t}from"./index-Cp0SHOD0.js";function s(){return t.get("/sign/dashboard/stats")}export{s as g};
