const Y="YYYY-MM-DD HH:mm:ss",D="YYYY-MM-DD";export{D,Y as a};
