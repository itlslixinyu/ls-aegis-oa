const n={TRANSFER:"银行转账",CASH:"现金",CHECK:"支票",OTHER:"其他"};function o(t){return t?n[t]||t:"-"}export{o as f};
