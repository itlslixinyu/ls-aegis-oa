import{j as o}from"./index-Cp0SHOD0.js";function t(n){return o.get(`/sign/file/${n}`)}function e(n){return`/sign/file/download/${n}`}function r(n){return o.download(e(n))}export{r as d,t as g};
